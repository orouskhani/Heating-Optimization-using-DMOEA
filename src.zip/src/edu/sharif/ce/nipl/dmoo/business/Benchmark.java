package edu.sharif.ce.nipl.dmoo.business;

import java.util.Random;

import org.uma.jmetal.util.front.Front;
import org.uma.jmetal.util.front.imp.ArrayFront;
import org.uma.jmetal.util.point.impl.ArrayPoint;

import edu.sharif.ce.nipl.dmoo.entity.Cat;


public class Benchmark {

	private int nVar;
	private double minVar;
	private double maxVar;
	private double nt;
	private double towet;
	private int nVar1;
	private double minVar1;
	private int nVar2;
	private double maxVar1;
	private double minVar2;
	private double maxVar2;
	private int func;
	private static int r;
	private static boolean flag;

	private Random rnd;
	private double[] p;
	private double[] Tideal;
	private double[] Tout;
	private int hours;
	private double beta;
	private double alpha;
	

	private static final double step = 0.01;

	public Benchmark(int nVar1 , int nVar2 , double minVar1 , double maxVar1 , double minVar2 , double maxVar2 , int func , int towet , int nt) {
		super();

		this.nVar = nVar1 + nVar2;
		this.nVar1 = nVar1;
		this.nVar2 = nVar2;

		this.minVar1 = minVar1;
		this.maxVar1 = maxVar1;

		this.minVar2 = minVar2;
		this.maxVar2 = maxVar2;

		this.func = func;

		rnd = new Random();

		r = -1;
		flag = false;


		this.towet = towet;
		this.nt = nt;

		p = new double[]{6.7874,7.5774,7.4313,3.9223,6.5548,1.7119,7.0605,0.31833,2.7692,0.46171,0.97132,8.2346,6.9483,3.171,9.5022,0.34446,4.3874,3.8156,7.6552,7.952,1.8687,4.8976,4.4559,6.4631};
		Tideal = new double[]{21.0736 , 21.5290 , 17.6349 , 21.5669 , 20.1618 , 17.4877 ,  18.3925 ,  19.7344 ,21.7875  , 21.8244  , 17.7881,   21.8530   ,21.7858,   19.4269 ,  21.0014 ,  17.7094 ,19.1088  , 21.5787  , 20.9610 ,  21.7975  , 20.2787 ,  17.1786  , 21.2456  , 21.6700};
		Tout = new double[]{-8 , -8 , -8 , -8 , -8 , -8 , -6 , -6 , -6 , -6 , -6 , -6 , -1 , -1 , -1 , -1 , -1 , -1 , -3 , -3 , -3 , -3 , -3 , -3};
		hours = nVar;
		
		beta = 0.038;
		alpha = 0.17;
		
	}


	public double evaluate(Cat cat, int relatedFunction , int iter){
		double result = 0;
		double[] position = cat.getPosition();
		if(relatedFunction == 0){
			for(int i = 0 ; i < hours ; i++){
				result += p[i] * position[i];  
			}
		}
		else if (relatedFunction == 1){
			for(int i = 0 ; i < hours ; i++){
				result += position[i];  
			}
		}
		else if (relatedFunction == 2){
			double[] T = new double[Tout.length];
			T[0] = 20;
			for(int i = 1 ; i < hours ; i++){
				T[i] = T[i-1] + beta * position[i] - alpha * beta * (T[i-1] - Tout[i-1]);  
			}
			T[0] = T[hours-1];
			for(int i = 0 ; i < T.length ; i++)
				result += Math.abs(T[i] - Tideal[i]);
		}
		return result;
	}



	public Front generatePFTrueForHeatingOptimization(){
		Front PFTrue = new ArrayFront(100 , 2);

		double i = 0;
		int index = 0;
		while(i <= 1){
			double x = i;
			double y = 1 - Math.sqrt(i);
			PFTrue.setPoint(index, new ArrayPoint(new double[]{x,y}));
			index++;
			i += step;
		}
		return PFTrue;
	}

}
