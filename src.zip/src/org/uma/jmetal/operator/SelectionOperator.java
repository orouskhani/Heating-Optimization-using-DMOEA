package org.uma.jmetal.operator;

/**
 * Created by Antonio J. Nebro on 04/09/14.
 */
public interface SelectionOperator<Source, Result> extends Operator<Source,Result> {
}
