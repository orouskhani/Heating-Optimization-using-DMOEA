package edu.sharif.ce.nipl.dmoo;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.uma.jmetal.util.front.Front;

import edu.sharif.ce.nipl.dmoo.business.CSOBusiness;
import edu.sharif.ce.nipl.dmoo.entity.Cat;


/**
 * 
 */

/**
 * @author Yasin
 *
 */
public class CSO {

	private static double percOfReinitialization = 0.3;
	private static int NUMCYCLE = 1;
	public static int HeatingOptimization = 1;
	
	public static Map<Integer , String> funcToString;
	
	private static int nt = 10;
	private static int towet = 10;
	
	public static void main(String[] args) throws Exception {

		
		funcToString = new HashMap<Integer , String>();
		funcToString.put(HeatingOptimization, "HeatingOptimization");
			
		int nPop = 100;
		int iter = 1000;
		
		int nVar1 = 0;
		int nVar2 = 0;
		
		double minVar1 = 0;
		double maxVar1 = 0;
		double minVar2 = 0;
		double maxVar2 = 0;
		
		int func = HeatingOptimization;
		
		if(func == HeatingOptimization){
			nVar1 = 24;
			nVar2 = 0;

			minVar1 = 0;
			maxVar1 = 10;

			minVar2 = 0;
			maxVar2 = 0;
		}
						
		int nVar = nVar1 + nVar2;
		
		Map<String , Double> finalResult = new HashMap<String , Double>();
		
		finalResult.put("Spacing", new Double(0));
		finalResult.put("GD", new Double (0));
		finalResult.put("IGD", new Double (0));
		finalResult.put("VGD", new Double (0));
		finalResult.put("MS", new Double (0));
		finalResult.put("HVR", new Double (0));
		finalResult.put("Acc", new Double (0));
		finalResult.put("AccAlt", new Double (0));
		finalResult.put("Stab1", new Double (0));
		finalResult.put("Stab2", new Double (0));
		finalResult.put("R2", new Double (0));

		for(int cycle = 0 ; cycle < NUMCYCLE ; cycle++){
			System.out.println("Cycle is : " + cycle);
			Random rnd = new Random();

			CSOBusiness buss = new CSOBusiness(nPop , nVar1 , nVar2 , minVar1 , maxVar1 , minVar2 , maxVar2 , func , cycle , towet , nt);
			buss.CSOInitialization();


			List<Cat> recognizableCats = new ArrayList<Cat>();
			int len = (int)(0.1 * nPop);
			for(int i = 0 ; i  < len ; i++){
				double[] rndPos = new double[nVar];
				for(int j = 0 ; j < rndPos.length ; j++){
					if (j < nVar1 ){
						rndPos[j] = minVar1 + (maxVar1 - minVar1) * rnd.nextDouble();
					}
					else{
						rndPos[j] = minVar2 + (maxVar2 - minVar2) * rnd.nextDouble();
					}
				}

				double[] rndVel = new double[nVar];
				recognizableCats.add(new Cat(i , rndPos, rndVel, Double.MAX_VALUE , false , 0 , 0));

			}



			for(int i = 1 ; i < iter + 1  ; i++){
				System.out.println("iter is:" + i);

				boolean isChanged = buss.IsEnvChanged(recognizableCats , i);

				if(isChanged && i != iter){

					//Front PFTrue = buss.generatePFTrue(i - 1, func);
					//write(PFTrue , i , "PFTrue");

					Front PFKnown = buss.calcPFKnown(i - 1);
					//write(PFKnown , i , "PFKnown");

					buss.calcSpacing(PFKnown);
					/*buss.calcGD(PFKnown , PFTrue);
					buss.calcIGD(PFKnown, PFTrue);
					buss.calcVGD(PFKnown , PFTrue);
					buss.calcMS(PFKnown , PFTrue);
					buss.calcHVR(PFKnown , PFTrue);
					buss.calcAcc(PFKnown , PFTrue);*/
					//buss.calcStab(PFKnown , PFTrue , i - 1);
					//buss.calcR(PFKnown , PFTrue);


					List<Integer> ranks = buss.calcNewFitness(i);
					buss.reinitializePopulation(ranks , percOfReinitialization , i);


				}
				buss.CSOMovement(i);
			}
			System.out.println("Finish");
			buss.CSOResultPlotting(iter);

			/*Map<String , Double> result = buss.printMetrics(iter);
			
			finalResult.put("Spacing", finalResult.get("Spacing") + result.get("Spacing"));
			finalResult.put("GD", finalResult.get("GD") + result.get("GD"));
			finalResult.put("IGD", finalResult.get("IGD") + result.get("IGD"));
			finalResult.put("VGD", finalResult.get("VGD") + result.get("VGD"));
			finalResult.put("MS", finalResult.get("MS") + result.get("MS"));
			finalResult.put("HVR", finalResult.get("HVR") + result.get("HVR"));
			finalResult.put("Acc", finalResult.get("Acc") + result.get("Acc"));
			finalResult.put("AccAlt", finalResult.get("AccAlt") + result.get("AccAlt"));
			finalResult.put("Stab1", finalResult.get("Stab1") + result.get("Stab1"));
			finalResult.put("Stab2", finalResult.get("Stab2") + result.get("Stab2"));
			finalResult.put("R2", finalResult.get("R2") + result.get("R2"));*/
			
			buss.writePOS(iter);
		}
		
		//printFinalResult(finalResult);
		//combineFiles(func , NUMCYCLE , iter);
	}
	
private static void combineFiles(int func , int cycles , int maxIter)throws Exception{
		
		String pofName = String.valueOf("pof-" + CSO.funcToString.get(func) + "-nt-" + String.valueOf(nt) + "-towet-" + String.valueOf(towet) + ".txt");
		String posName = String.valueOf("pos-" + CSO.funcToString.get(func) + "-nt-" + String.valueOf(nt) + "-towet-" + String.valueOf(towet) + ".txt");
		for(int iter = 1 ; iter < maxIter + 1 ; iter++){
			String pofCycleInfo = "";
			String posCycleInfo = "";
			for(int cycle = 0 ; cycle < cycles ; cycle++){
				// POF
				pofCycleInfo = pofCycleInfo.concat("[");
				String pofFilename = "pof-" + funcToString.get(func) + "-" + String.valueOf(cycle) + "-" + String.valueOf(iter) + ".txt";
				String pofContent = readFile(pofFilename);
				pofCycleInfo = pofCycleInfo.concat(pofContent).concat("]");
				
				// POS
				posCycleInfo = posCycleInfo.concat("[");
				String posFilename = "pos-" + funcToString.get(func) + "-" + String.valueOf(cycle) + "-" + String.valueOf(iter) + ".txt";
				String posContent = readFile(posFilename);
				posCycleInfo = posCycleInfo.concat(posContent).concat("]");
				
			}
			
			PrintWriter pofOut = new PrintWriter(new BufferedWriter(new FileWriter("./final/" + pofName , true)));
			pofOut.println(String.valueOf(iter));
			pofOut.println(pofCycleInfo);
			pofOut.close();
			
			PrintWriter posOut = new PrintWriter(new BufferedWriter(new FileWriter("./final/" + posName , true)));
			posOut.println(String.valueOf(iter));
			posOut.println(posCycleInfo);
			posOut.close();
			
		}
		
		final File folder = new File(".");
		final File[] files = folder.listFiles(new FilenameFilter() {
			
			@Override
			public boolean accept(File arg0, String arg1) {
				return !arg1.contains("towet");
			}
		});
		
		for(int iter = 1 ; iter < maxIter + 1 ; iter++){
			for(int cycle = 0 ; cycle < cycles ; cycle++){
				String pofFilename = "pof-" + funcToString.get(func) + "-" + String.valueOf(cycle) + "-" + String.valueOf(iter) + ".txt";
				String posFilename = "pos-" + funcToString.get(func) + "-" + String.valueOf(cycle) + "-" + String.valueOf(iter) + ".txt";
				
				File pofFile = new File(pofFilename);
				pofFile.delete();
				
				File posFile = new File(posFilename);
				posFile.delete();

			}
			
		}
		
		
		
	}

	private static String readFile(String filename) throws Exception{
		String contents = "";
		FileInputStream inputStream = new FileInputStream(filename);
		DataInputStream in = new DataInputStream(inputStream);
		BufferedReader bf = new BufferedReader(new InputStreamReader(in));
		
		String line = bf.readLine();
		while(line != null){
			contents = contents.concat("[").concat(line).concat("]");
			line = bf.readLine();
			if(line != null)
				contents = contents.concat(",");
		}
		
		return contents;
		
	}

	private static void printFinalResult(Map<String, Double> finalResult) {
		System.out.println("Spacing :" + finalResult.get("Spacing") / NUMCYCLE);
		System.out.println("GD : " + finalResult.get("GD")/ NUMCYCLE);
		System.out.println("IGD : " + finalResult.get("IGD")/ NUMCYCLE);
		System.out.println("VGD : " + finalResult.get("VGD")/ NUMCYCLE);
		System.out.println("MS : " + finalResult.get("MS")/ NUMCYCLE);
		System.out.println("HVR : " + finalResult.get("HVR")/ NUMCYCLE);
		System.out.println("Acc : " + finalResult.get("Acc")/ NUMCYCLE);
		System.out.println("AccAlt : " + finalResult.get("AccAlt")/ NUMCYCLE);
		System.out.println("Stab1 : " + finalResult.get("Stab1")/ NUMCYCLE);
		System.out.println("Stab2 : " + finalResult.get("Stab2")/ NUMCYCLE);
		System.out.println("R2 : " + finalResult.get("R2")/ NUMCYCLE);
	}

	private static void write(Front pof , int iter , String filename) throws IOException {
		BufferedWriter outputWriter = null;
		outputWriter = new BufferedWriter(new FileWriter(filename + String.valueOf(iter) + ".txt"));
		for (int i = 0; i < pof.getNumberOfPoints() ; i++) {
			double cost1 = pof.getPoint(i).getDimensionValue(0);
			outputWriter.write(String.valueOf(cost1));
			outputWriter.write(",");
			double cost2 = pof.getPoint(i).getDimensionValue(1);
			outputWriter.write(String.valueOf(cost2));
			outputWriter.newLine();
		}
		outputWriter.flush();  
		outputWriter.close();  
	}

}
